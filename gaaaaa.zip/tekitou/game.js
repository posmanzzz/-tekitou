document.addEventListener('DOMContentLoaded', () => {
    const board = document.getElementById('game-board');
    const context = board.getContext('2d');
    const scoreElement = document.getElementById('score');
    const highScoreElement = document.getElementById('high-score');
    const gameOverScreen = document.getElementById('game-over-screen');
    const finalScoreElement = document.getElementById('final-score');
    const finalHighScoreElement = document.getElementById('final-high-score');
    const restartButton = document.getElementById('restart-button');
    const startScreen = document.getElementById('start-screen');
    const difficultyButtons = document.querySelectorAll('.btn-difficulty');
    const skinButtons = document.querySelectorAll('.btn-skin');
    const mobileControlButtons = document.querySelectorAll('.btn-control');

    const gridSize = 20;
    const HIGH_SCORE_KEY = 'snakeGameHighScore';
    const SKIN_KEY = 'snakeGameSkin';
    let highScore = 0;

    const difficultySettings = {
        easy: 180,   // Slower
        normal: 120, // Default
        hard: 70     // Faster
    };

    const skinPalettes = {
        classic: {
            snake: '#58a6ff',
            food: '#2ea043'
        },
        fire_ice: {
            snake: '#ff7b72', // Fire color
            food: '#79c0ff'  // Ice color
        }
    };
    let currentSkin = 'classic';

    let snake = [{ x: 10, y: 10 }];
    let food = {};
    let score = 0;
    let direction = 'right';
    let changingDirection = false;
    let speed; // ms per update. Lower is faster.
    let gameOver = false;
    let lastUpdateTime = 0;
    let animationFrameId;

    function loadHighScore() {
        const storedHighScore = localStorage.getItem(HIGH_SCORE_KEY);
        highScore = storedHighScore ? parseInt(storedHighScore, 10) : 0;
        highScoreElement.textContent = highScore;
    }

    function saveHighScore() {
        localStorage.setItem(HIGH_SCORE_KEY, highScore.toString());
    }

    function loadSkin() {
        const storedSkin = localStorage.getItem(SKIN_KEY);
        currentSkin = storedSkin || 'classic';
        updateSkinButtons();
    }

    function saveSkin(skinName) {
        currentSkin = skinName;
        localStorage.setItem(SKIN_KEY, skinName);
        updateSkinButtons();
    }

    function startGame(initialSpeed) {
        speed = initialSpeed;

        // Reset game state
        snake = [{ x: 10, y: 10 }];
        score = 0;
        direction = 'right';
        scoreElement.textContent = score;
        highScoreElement.textContent = highScore;
        gameOverScreen.classList.add('hidden');
        startScreen.classList.add('hidden');
        board.classList.remove('hidden');
        gameOver = false;
        lastUpdateTime = 0;
        
        generateFood();

        // Start the game loop
        if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
        }
        requestAnimationFrame(main);
    }

    function main(currentTime) {
        animationFrameId = requestAnimationFrame(main);

        if (gameOver) return;

        // Update game state at a fixed interval (based on 'speed')
        const timeSinceLastUpdate = currentTime - lastUpdateTime;
        if (timeSinceLastUpdate > speed) {
            lastUpdateTime = currentTime;

            changingDirection = false;
            moveSnake();

            if (didGameEnd()) {
                gameOver = true;
                showGameOver();
            }
        }

        // Draw the game state on every frame for smoothness
        clearCanvas();
        drawFood();
        drawSnake();
    }

    function clearCanvas() {
        context.fillStyle = '#0d1117';
        context.fillRect(0, 0, board.width, board.height);
    }

    function drawSnake() {
        snake.forEach(drawSnakePart);
    }

    function drawSnakePart(snakePart) {
        context.fillStyle = skinPalettes[currentSkin].snake;
        context.strokeStyle = '#0d1117'; // Snake border
        context.fillRect(snakePart.x * gridSize, snakePart.y * gridSize, gridSize, gridSize);
        context.strokeRect(snakePart.x * gridSize, snakePart.y * gridSize, gridSize, gridSize);
    }

    function drawFood() {
        context.fillStyle = skinPalettes[currentSkin].food;
        context.strokeStyle = '#0d1117';
        context.fillRect(food.x * gridSize, food.y * gridSize, gridSize, gridSize);
        context.strokeRect(food.x * gridSize, food.y * gridSize, gridSize, gridSize);
    }

    function generateFood() {
        food.x = Math.floor(Math.random() * (board.width / gridSize));
        food.y = Math.floor(Math.random() * (board.height / gridSize));
        // Ensure food is not on the snake
        snake.forEach(part => {
            if (part.x === food.x && part.y === food.y) {
                generateFood();
            }
        });
    }

    function moveSnake() {
        const head = { x: snake[0].x, y: snake[0].y };
        switch (direction) {
            case 'up': head.y -= 1; break;
            case 'down': head.y += 1; break;
            case 'left': head.x -= 1; break;
            case 'right': head.x += 1; break;
        }
        snake.unshift(head);

        const didEatFood = snake[0].x === food.x && snake[0].y === food.y;
        if (didEatFood) {
            score += 10;
            scoreElement.textContent = score;
            // Increase speed slightly
            if (speed > 60) { // Set a max speed
                speed -= 2;
            }
            generateFood();
        } else {
            snake.pop();
        }
    }

    function setDirection(newDirection) {
        if (changingDirection) return;

        const goingUp = direction === 'up';
        const goingDown = direction === 'down';
        const goingLeft = direction === 'left';
        const goingRight = direction === 'right';

        if (newDirection === 'up' && !goingDown) {
            direction = 'up';
            changingDirection = true;
        }
        if (newDirection === 'down' && !goingUp) {
            direction = 'down';
            changingDirection = true;
        }
        if (newDirection === 'left' && !goingRight) {
            direction = 'left';
            changingDirection = true;
        }
        if (newDirection === 'right' && !goingLeft) {
            direction = 'right';
            changingDirection = true;
        }
    }

    function handleKeyPress(event) {
        const keyMap = { 'ArrowUp': 'up', 'ArrowDown': 'down', 'ArrowLeft': 'left', 'ArrowRight': 'right' };
        const newDirection = keyMap[event.key];
        if (newDirection) {
            setDirection(newDirection);
        }
    }

    function didGameEnd() {
        // Check for wall collision
        const hitLeftWall = snake[0].x < 0;
        const hitRightWall = snake[0].x >= board.width / gridSize;
        const hitTopWall = snake[0].y < 0;
        const hitBottomWall = snake[0].y >= board.height / gridSize;

        if (hitLeftWall || hitRightWall || hitTopWall || hitBottomWall) {
            return true;
        }

        // Check for self collision
        for (let i = 4; i < snake.length; i++) {
            if (snake[i].x === snake[0].x && snake[i].y === snake[0].y) {
                return true;
            }
        }
        return false;
    }
    
    function showGameOver() {
        cancelAnimationFrame(animationFrameId);
        if (score > highScore) {
            highScore = score;
            saveHighScore();
        }
        finalScoreElement.textContent = score;
        finalHighScoreElement.textContent = highScore;
        board.classList.add('hidden');
        gameOverScreen.classList.remove('hidden');
    }

    function showStartScreen() {
        gameOverScreen.classList.add('hidden');
        startScreen.classList.remove('hidden');
    }

    function updateSkinButtons() {
        skinButtons.forEach(button => {
            button.classList.remove('active');
            if (button.dataset.skin === currentSkin) {
                button.classList.add('active');
            }
        });
    }

    difficultyButtons.forEach(button => {
        button.addEventListener('click', () => {
            const difficulty = button.dataset.difficulty;
            startGame(difficultySettings[difficulty]);
        });
    });

    skinButtons.forEach(button => {
        button.addEventListener('click', () => {
            const skin = button.dataset.skin;
            saveSkin(skin);
        });
    });

    mobileControlButtons.forEach(button => {
        button.addEventListener('click', () => {
            const newDirection = button.dataset.direction;
            setDirection(newDirection);
        });
    });

    document.addEventListener('keydown', handleKeyPress);
    restartButton.addEventListener('click', showStartScreen);

    // Load saved settings and wait for user to select difficulty
    loadHighScore();
    loadSkin();
});