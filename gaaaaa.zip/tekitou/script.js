document.addEventListener('DOMContentLoaded', function() {
    // ライトボックスのモーダル要素を取得
    const modal = document.getElementById('lightbox-modal');
    const modalImg = document.getElementById('lightbox-image');

    // ギャラリーのすべての画像を取得
    const galleryImages = document.querySelectorAll('.image-gallery img');

    // 各画像にクリックイベントを追加
    galleryImages.forEach(image => {
        image.addEventListener('click', function() {
            modal.style.display = 'block';
            modalImg.src = this.src;
        });
    });

    // 閉じるボタン（×）を取得
    const closeBtn = document.querySelector('.lightbox-close');

    // 閉じるボタンがクリックされたらモーダルを非表示にする
    closeBtn.onclick = function() {
        modal.style.display = 'none';
    }

    // モーダルの背景がクリックされたらモーダルを非表示にする
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
});